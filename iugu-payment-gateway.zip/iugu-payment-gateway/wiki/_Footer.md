**Última versão em produção**: v2.0.1 <br />
**Precisa de ajuda?** Veja como obter [suporte para o plugin](https://github.com/iugu/iugu-woocommerce/wiki/Suporte). <br />
**Colabore**: faça fork do repositório e envie seus pull requests para aprovação.
