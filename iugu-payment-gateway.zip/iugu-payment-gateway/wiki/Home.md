# WooCommerce iugu

Receba pagamentos por cartão de crédito e boleto na sua loja WooCommerce com a iugu.

A iugu disponibiliza toda a infraestrutura necessária para que você possa transacionar pagamentos online com menos burocracia e mais vantagens. Com a nossa plataforma, você pode oferecer pagamentos com checkout transparente com cartão de crédito e boleto bancário. Para mais informações sobre o funcionamento da iugu, [leia a documentação](https://docs.iugu.com).