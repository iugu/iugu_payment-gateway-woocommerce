/*jshint devel: true */
(function($) {
    'use strict';
    $(function() {
        const clipboard = new ClipboardJS('#iugu_pix_qrcode_text_button');
    });
}(jQuery));